# MV-HSI-CNN_network

There are two files ----- MV-HSI-CNN_network.ipynb
                    ------Copy_of_practical_mv_8_8.ipynb
                    
                    Here in MV-HSI-CNN network all combinations are given 
                    data size is reshaped - neglect it or comment it and run the code
                    
                    
                    
                    
