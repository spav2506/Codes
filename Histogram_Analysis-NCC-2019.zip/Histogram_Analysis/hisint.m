%% Coded by Pavan Sandula considering..



function [ sumkl] = hisint( H1,H2)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
XH1=H1;
XH2=H2;
ri=size(H1,2);
    for i=1:ri
         if(XH1(i)~=0&&XH2(i)~=0)
              DIS(i)=min(XH1(i),XH2(i))/sum(H2);
         end
         if(XH1(i)==0&& XH2(i)~=0)
             DIS(i)=0;
         end
         if(XH1(i)==0&&XH2(i)==0)
             DIS(i)=0;
         end
         if(XH1(i)~=0&&XH2(i)==0)
             DIS(i)=0;
         end        
    end
sumkl=sum(DIS);
end