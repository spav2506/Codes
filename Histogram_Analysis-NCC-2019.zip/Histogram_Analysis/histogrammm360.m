%% Coded by Pavan Sandula


function [ c ] = histogrammm360( image)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[m,n]=size(image);
c=zeros(1,361);
for k=0:360
for i=1:m
    for j=1:n
        if(image(i,j)==k)
            c(k+1)=c(k+1)+1;
        end
    end
end
end


end