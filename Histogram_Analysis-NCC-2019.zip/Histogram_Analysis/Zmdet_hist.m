%% =========================== zoomcameramotion_detection&classification.m ========================== %
%
% Description          :  This code is used for "Getting features for zoom camera motion detection
%                         and classification" using Histogram based analysis
%                         with a constrained features using the Histogram Intersection 
%                         and KL Divergence measures.
%                        
%                         
%                         
%
% Input parameters     :    ESME block motion vectors
%
%
% Output parameters    :    Feature vector representing the
%                           predefined zoom camera motion and its classes
%
% Subroutine  called   :    NA
% Called by            :    NA
% Reference            :    Manish Okade, Gaurav Patel, Prabir Kumar Biswas,
%                           �Robust Learning based Camera Motion Characterization scheme with Application to Video Stabilization,"
%                           IEEE Transactions on Circuits and Systems for Video Technology, vol. 26, no. 3, pp. 453-466, March 2016. 
% Author of the code   :    Sandula Pavan (516ec6004@gmail.com)
% Date of creation     :    24.01.2018
% --------------------------------------------------------------------- %
% Modified on          :    
% Modification details :    variable name and comments
% Modified By          :    
% ================================================================ %
%           ECE Department, NIT Rourkela, India.
% ================================================================ %












%%
clc;
clear all;
close all;
%% path to read motion vector
path='G:\ESME\non-zoom_mv_4\matlabmv_';
% path='G:\H.264\zoom_mv_4\mv_';
% path='G:\ESME\zoom_out\matlabmv_'
BLK_H=72%60 72

BLK_W=88%

 HALF_PIX=0.5;
 t23=1;
%% Read each frame
for frameNum=1:1000
    
    
    t35=0;
%% Read motion vector.

    [mv_x, mv_y] = ReadMVs(path, frameNum, BLK_H, BLK_W, HALF_PIX);

    L=sqrt(mv_x.^2+mv_y.^2);Mx=max(L(:));
    [w1 w2]=size(mv_x);

%P1=histogrammmax(L,71);
%% quiver plot for mvs

h= quiver(mv_x,mv_y);
a=(h.UData);
b=(h.VData);

 %% obtaining orientation between 0^o and 360^o
for p=1:size(a,1)
    for q=1:size(a,2)
        if a(p,q)>0 && b(p,q)>0 
            A(p,q)= 180*atan(b(p,q)/a(p,q))/pi;
        end
        if a(p,q)<0 && b(p,q)>0
            A(p,q)=90+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
        end
        
        if a(p,q)<0 && b(p,q)<0
            A(p,q)=180+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
        end
        
        if a(p,q)>0 && b(p,q)<0
            A(p,q)=270+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
        end
        if a(p,q)<0 && b(p,q)==0
            A(p,q)=180;
        end
        if a(p,q)==0&& b(p,q)<0
            A(p,q)=270;
        end
        if a(p,q)==0 && b(p,q)>0
            A(p,q)=90;
        end
        if a(p,q)>0 && b(p,q)==0
            A(p,q)=0;
        end
        if a(p,q)==0 && b(p,q)==0
            A(p,q)=0;
        end
    end
end
A=round(round(A));
%% Dividing Angle Space into four quadrants
A1=abs(A((BLK_H/2)+1:BLK_H,(BLK_W/2)+1:BLK_W));
A2=abs(A((BLK_H/2)+1:BLK_H,1:(BLK_W/2)));
A3=abs(A(1:(BLK_H/2),1:(BLK_W/2)));
A4=abs(A(1:(BLK_H/2),(BLK_W/2)+1:BLK_W));
%% Computing histogram for four Quadrants of angle space
H1=histogrammm360(A1);
H2=histogrammm360(A2);
H3=histogrammm360(A3);
H4=histogrammm360(A4);
H=H1+H2+H3+H4;
%% Calculating histogram intersection between 1 and 3 , between 1 and 2, between 4 and 3
HI2=hisint(H3,H4);
HI4=hisint(H1,H3);
HI5=hisint(H1,H2);
HI6=hisint(H2,H4);
% KL6=hisint(H2,H3);
HI=[HI5 HI4 HI6 HI2];
%fv=[HI];
%filename3 =strcat('G:\ConcHist\train8\Hist_data\ESME\non-zoom\FV',num2str(t23),'.csv');
%csvwrite(filename3,fv);
%% Calculating histogram intersections max value as feature
h_i=max(KL);
%% Obtain normalized histogram probability
Hx=H1./sum(H1);
Hy=H2./sum(H2);
Hz=H4./sum(H4);
Hs=H3./sum(H3);
%Dis=JD(Hx,Hy);
%% zoom classification
%% Finding cumulative distribution to four quadrants histogram
%az=0;az1=0;az2=0;az3=0;
%for i=1:size(Hx,2)
%    Hx(i)=Hx(i)+az;
%    az=Hx(i);
%    Hy(i)=Hy(i)+az1;
%    az1=Hy(i);
%    Hz(i)=Hz(i)+az2;
%    az2=Hz(i);
%    Hs(i)=Hs(i)+az3;
%    az3=Hs(i);
%end
%% Finding Kl distance between 1 and 3 and between 1 and 2

%St2=kldis(Hx,Hs);
%St3=kldis(Hx,Hz);
%St4=kldis(Hy,Hs);
%St5=kldis(Hy,Hz);
%% obtain minimum distance between these two Kl dis and give as feature
%KL=([St2,St3,St5,St4]);

% fv=[KL];
% filename3 =strcat('G:\ConcHist\train8\Hist_data\ESME\zoom-in\FV',num2str(t23),'.csv');
% csvwrite(filename3,fv);
%% writing the feature vector to specified file

  t23=t23+1;


end
