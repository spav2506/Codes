%% =========================== camera_classification.m ========================== %
%
% Description          :  This code is used for " Camera zoom motion detection and
%                         to distinguish zoom-in from zoom-out camera type 
%                         using curl" Here basically pattern are oriented
%                         as convergent or divergent. Therefore the
%                         analysis was carried in compressed domain optical
%                         flow to study the nature of curl on it in both
%                         real codec and ideal with Gaussian noise adding
%                         to it were analysed. 
%                         
%                           
%                         
%                        
%                         
%                         
%
% Input parameters     :    H.264 block motion vectors
%
%
% Output parameters    :    Classification labels representing the
%                           predefined camera motion classes
%
% Subroutine  called   :    NA
% Called by            :    NA
% Reference            :    1)Erwin Kreyszig. Advanced Engineering Mathematics. 
%                              John Wiley & Sons, Inc., New York, NY, USA, 8th edition, 2000.
%
%                              
%                             
% Author of the code   :    Sandula Pavan (pavannit4@gmail.com)
% Date of creation     :    22.05.2019
% --------------------------------------------------------------------- %
% Modified on          :    
% Modification details :    variable name and comments
% Modified By          :    
% ================================================================ %
%           ECE Department, NIT Rourkela, India.
% ================================================================ %





%%
clc;
clear all;
close all;

%% Intialization of Block height and width and Weighs

weight5=[2^3 90 45;2^4,0,2^0;2^5,2^6,2^7];
                           
path='G:\H.264\zoom_mv_4\mv_';
path='G:\ESME\zoom_out\matlabmv_';
stdDev = [0.7, 1.5, 2.2, 3.0, sqrt(10), sqrt(20), sqrt(30)];

%path='G:\ESME\zoom_mv_4\matlabmv_';
% path='G:\H.264\zoom_out1\matlabmv_';
BLK_W=88%
BLK_H=72 
HALF_PIX=0.5;
t23=1;x1=1;
W=[-1 0;0 1];
wei=[2^0 ; 2^1; 2^2; 2^3];
% W2=W1';
var = [-1 1 0;-1 1 0];
%% Main code starts with different motion vector frame count
nm=1;
for frameNum=1:1000

    t23;
%     tic
%% ESME Zoom-in and zoom-out data for table_tennis_sif


%   if t23>122 && t23<=166 %%zoom-out
%         BLK_H=60; 
%   else
%         BLK_H=72;
%   end
%   if t23>=122 && t23<164 %% zoom-in
%         BLK_H=60;
%   else
%         BLK_H=72;
%   end 
% %   
  
%% H.264 Zoom-in and zoom-out data for table_tennis_sif
  
%   if t23>=124 && t23<168 %% zoom-in (+) %% zoom-out(+=)
%         BLK_H=60;
%   else
%         BLK_H=72;
%   end
  
  
%% Read motion vector.                                                  
tic;
  [mv_x, mv_y] = ReadMVs(path, frameNum, BLK_H, BLK_W, HALF_PIX);
  [w1,w2] =size(mv_x);

% Addition of Noise
  
%            nX = stdDev(1,7).*randn(w1, w2);
%            mv_x = round(mv_x+nX);
%            nY = stdDev(1,7).*randn(w1, w2);
%            mv_y = round(mv_y+nY);
  
%% Pad the mv_x and mv_y and form complex number Locally
  a=(mv_x);
  b=(mv_y);

a= (a>0)*1+(a<0)*(-1);
b= (b>0)*1+(b<0)*(-1);
A=a+1i*b;



%% Partitioning Orientation space into four quadrants

A1=(A((BLK_H/2)+1:BLK_H,(BLK_W/2)+1:BLK_W));


A2=(A((BLK_H/2)+1:BLK_H,1:(BLK_W/2)));

A3=(A(1:(BLK_H/2),1:(BLK_W/2)));

A4=(A(1:(BLK_H/2),(BLK_W/2)+1:BLK_W));


%% Resulatant vector from four quadrants
S1=mean(mean(A1));
S2=mean(mean(A2));
S3=mean(mean(A3));
S4=mean(mean(A4));
Dev1= [0 0 ((S2)-(S3))];
Dev2=[ 0 0 ((S1)-(S4))];

v1=cross(Dev1,[1 1 0]);
v2=cross(Dev2,[1 1 0]);
FG1=[1 1 ; v1(1,1:2)];
FG2=[1 1 ; v2(1,1:2)];
D_FG1=(det(FG1));
D_FG2=(det(FG2));
% D_FG3=det(FG3);
% D_FG4=det(FG4);
SDER=([D_FG1+D_FG2]);
Real_c=real(SDER);
Imag_c=imag(SDER);

fv(:,t23)=[Real_c ;Imag_c];

% Imag_c
% if Imag_c>0
%     disp('zoom-out');
%     nm=nm+1
% else 
%     disp('zoom-in');
% end
%  csvwrite('gau30_zoom_curl_data.xls',fv');

%% Finding Curl
FG(t23)=toc;

  t23=t23+1;

end
% min(abs(Q1))
% max(abs(Q1))
% median(abs(fv))
% mean(FG)