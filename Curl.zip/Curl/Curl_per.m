clc;
clear all
close all



S1=load('gau20_zoom_curl_data.xls');
S2=load('gau20_non-zoom_curl_data.xls');
out=vertcat(S1,S2);
labels(1:1000)=1;
    labels(1001:2000)=2;k=1;
  klx=1;Ax=0;Bx=0;
%  while(klx<=30)
     indices = crossvalind('Kfold',labels',5);  

cp = classperf(labels');
for ix = 1:5
    train = (indices == ix);
    if ix~=5
    train1= (indices==ix+1);
    else
    train1= (indices==1);
    end
    train2=train+train1;
    train2=train2>0;
    test = ~train2;
    k=1;
    tic
k2=1;
% % % % % for i=-5:0.5:3
% for j=0.1:0.5:10
% % 
% svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','linear','Kernelscale','auto','BoxConstraint',j);
% CVSVMModel = crossval(svmmodel,'KFold',5);
% classLoss(k2) = kfoldLoss(CVSVMModel);
% S(:,k2)=[j];
% k2=k2+1;
% end
% % % end
% [idx Lo]=min(classLoss);
% % % % svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale',2^S(1,Lo),'BoxConstraint',2^S(2,Lo));
% svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','linear','Kernelscale','auto','BoxConstraint',S(1,Lo));%%
svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale','auto');%,'BoxConstraint',S(1,Lo));%


[labelpredict,score]=predict(svmmodel,out(test,:));
conf=confusionmat(labels(:,test),labelpredict);
acc(ix)=(conf(1,1)+conf(2,2))/size(out(test,:),1);
Time(ix)=toc;
ClassNames=[1;2];
ClassNames=ClassNames<2;
% score(:,ClassNames);


k=k+1;
    

% % % k=k+1; % % end % % 
% [Acc, LP]=max(acc); % %     class =
%%% classify(out(test,:),out(train,:),labels(:,train));
    classperf(cp,labelpredict,test);
end
labelpredict=labelpredict<2;
labels2=labels(:,test)<2;
score(:,ClassNames);
[Xsvm,Ysvm,Tsvm,AUC2] = perfcurve(labels2,score(:,ClassNames),'true');
se=find(Xsvm<=0.01);
tp=Ysvm(se(end,end));
tn=0.99;
perAcc(klx)=((tp+tn)/2)*100;

AreaUC(klx)=AUC2;

CX(klx)=mean(acc);
CY(klx)=sum(Time);
klx=klx+1
%  end
Mean_AUC=mean(AreaUC)
Mean_acc=mean(CX)
Mean_time=sum(CY)
overallAcc=mean(perAcc)