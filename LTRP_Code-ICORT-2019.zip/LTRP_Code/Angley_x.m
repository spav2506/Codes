function [A]=Angley_x(a,b)
Angle=zeros(size(a));
A=zeros(size(a));
for p=1:size(a,1)
    for q=1:size(a,2)
        if a(p,q)>0 && b(p,q)>0 
            A(p,q)= 180*atan(b(p,q)/a(p,q))/pi;
            Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
            Lambda(p,q)=2;
        end
        if a(p,q)<0 && b(p,q)>0
            A(p,q)=90+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
             Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
             Lambda(p,q)=4;
        end
        
        if a(p,q)<0 && b(p,q)<0
            A(p,q)=180+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
             Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
             Lambda(p,q)=6;
        end
        
        if a(p,q)>0 && b(p,q)<0
            A(p,q)=270+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
              Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
              Lambda(p,q)=8;
        end
        if a(p,q)<0 && b(p,q)==0
            A(p,q)=180;
            Angle(p,q)=-180;
            Lambda(p,q)=3;
        end
        if a(p,q)==0&& b(p,q)<0
            A(p,q)=270;
            Angle(p,q)=-90;
            Lambda(p,q)=5;
        end
        if a(p,q)==0 && b(p,q)>0
            A(p,q)=90;
            Angle(p,q)=90;
            Lambda(p,q)=1;
        end
        if a(p,q)>0 && b(p,q)==0
            A(p,q)=0;
            Angle(p,q)=0;
            Lambda(p,q)=0;
        end
        if a(p,q)==0 && b(p,q)==0
            A(p,q)=0;
            Angle(p,q)=0;
            Lambda(p,q)=-2;
        end
    end
end