%% =========================== zoomcameramotion_detection.m ========================== %
%
% Description          :  This code is used for "Getting features for zoom detection
%                         " using LTrP texture analysis
%                         method.We basically aim at representing the 
%                         compressed domain block motion vectors in 
%                         orientation space, and obtain tetra patterns between its correspondings......
%                         and dimensionality reduction using uniform patterns are considered separately 
%                         by concatenating both and its ratio for feeding the feature vectors.... 
%                         
%                        
%                         
%                         
%
% Input parameters     :    ESME block motion vectors
%
%
% Output parameters    :    Feature vectors for representing the
%                           predefined camera motion classes...
%
% Subroutine  called   :    NA
% Called by            :    NA
% Reference            :    1)Subramanyam Murala, R.P.Maheswari and R.Balasubramanian,"Local Tetra Patterns: A 
%                             New Feature Descriptor for Content- Based Image Retrieval" IEEE 
%                             transaction on image processing, VOL. 21,No. 5, May 2012 
% Author of the code   :    Sandula Pavan (pavannit4@gmail.com)
% Date of creation     :    24.06.2019
% --------------------------------------------------------------------- %
% Modified on          :    
% Modification details :    variable name and comments
% Modified By          :    
% ================================================================ %
%           ECE Department, NIT Rourkela, India.
% ================================================================ %













%%
clc;
clear all;
close all;




BLK_H=72%60 72
path='G:\H.264\zoom_mv_4\mv_';
path='G:\ESME\non-zoom_mv_4\matlabmv_';
stdDev = [0.7, 1.5, 2.2, 3.0, 10, 20, 30];
BLK_W=88%
%  unipat=[0;1;2;3;4;6;7;8;12;14;15;16;24;28;30;31;32;48;56;60;62;63;64;96;112;120;124;126;127;128;129;131;135;143;159;191;192;193;195;199;207;223;224;225;227;231;239;240;241;243;247;248;249;251;252;253;254;255];
 HALF_PIX=0.5;
 BLK_SZ=4;
t23=1;
%% Main code starts with different motion vector frame count
for frame = 1:1000
[mv_x, mv_y] = ReadMVs(path, frame, BLK_H, BLK_W, HALF_PIX);

[w1 w2 ]=size(mv_x);
            nX = stdDev(1,7).*randn(w1, w2);
            mv_x = round(mv_x+nX);
            nY = stdDev(1,7).*randn(w1, w2);
            mv_y = round(mv_y+nY);
%% quiver plot for mvs
%figure(1)
% h= quiver(mv_x,mv_y);
%% Fix center and find corresponding angles with it for quiver plot
    a=mv_x(:,:);
    b=mv_y(:,:);
    L=sqrt(a.^2+b.^2);
    Mon=0;
 
for p=1:size(a,1)
    for q=1:size(a,2)
        if a(p,q)>0 && b(p,q)>0 
            A(p,q)= 180*atan(b(p,q)/a(p,q))/pi;
        end
        if a(p,q)<0 && b(p,q)>0
            A(p,q)=90+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
        end
        
        if a(p,q)<0 && b(p,q)<0
            A(p,q)=180+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
        end
        
        if a(p,q)>0 && b(p,q)<0
            A(p,q)=270+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
        end
        if a(p,q)<0 && b(p,q)==0
            A(p,q)=180;
        end
        if a(p,q)==0&& b(p,q)<0
            A(p,q)=270;
        end
        if a(p,q)==0 && b(p,q)>0
            A(p,q)=90;
        end
        if a(p,q)>0 && b(p,q)==0
            A(p,q)=0;
        end
        if a(p,q)==0 && b(p,q)==0
            A(p,q)=0;
        end
    end
end
[H1 H2 H3 H4 H5 H6 H7 H8 H9 H10 H11 H12 M]=LTRP_MET(A);
h1=unihist(H1);
h2=unihist(H2);
h3=unihist(H3);
h4=unihist(H4);
h5=unihist(H5);
h6=unihist(H6);
h7=unihist(H7);
h8=unihist(H8);
h9=unihist(H9);
h10=unihist(H10);
h11=unihist(H11);
h12=unihist(H12);
m=unihist(M);
F.v=[h1(:); h2(:);h3(:);h4(:);h5(:);h6(:);h7(:);h8(:);h9(:);h10(:);h11(:);h12(:);m(:)];
fv=F.v';
%filename=strcat('G:\Globalzoom\data_TT\gan30\non-zoom\FV',num2str(t23),'.csv');
%csvwrite(filename,fv);
  t23=t23+1;
end
