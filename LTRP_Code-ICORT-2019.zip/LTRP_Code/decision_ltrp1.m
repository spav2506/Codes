%% Coded by Sandula



%%%%%% National Institute of Technology Rourkela %%%%%%




function[W]=decision_ltrp1(hp1,yp1)

           if hp1>=45 && yp1 >45
                W=1;
              else if hp1<45 && yp1>=45
                    W=0;
                else if hp1<45 && yp1<45
                        W=3;
                    else 
                        W=4;
                    end
                end
            end