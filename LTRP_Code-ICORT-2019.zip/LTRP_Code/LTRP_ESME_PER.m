function [Xsvm,Ysvm, Mean_AUC, Mean_acc,Mean_time,overallAcc] =LTRP_ESME_PER()
fp1=strcat('G:\Globalzoom\data_TT\zoom\FV',num2str(1),'.csv');
    out=csvread(fp1);
for i1=2:1000
     fp1=strcat('G:\Globalzoom\data_TT\zoom\FV',num2str(i1),'.csv');
    new=csvread(fp1);  % Read the nth file
   out = vertcat(out, new);   % Concatenate "out" with the 2nd column from new file
end
for j1=1:1000
    fp25=strcat('G:\Globalzoom\data_TT\non-zoom\FV',num2str(j1),'.csv');
    new2=csvread(fp25);
    out=vertcat(out,new2);
end
% fp11=strcat('G:\ConcHist\train8\ESME\motionvector\FV',num2str(1),'.csv');
%     out1=csvread(fp11);
% for i1=2:111
%      fp11=strcat('G:\ConcHist\train8\ESME\motionvector\FV',num2str(i1),'.csv');
%     new1=csvread(fp11);  % Read the nth file
%    out1 = vertcat(out1, new1);   % Concatenate "out" with the 2nd column from new file
% end
labels(1:1000)=1;
    labels(1001:2000)=2;k=1;
    klx=1;Ax=0;Bx=0;
while(klx<=30)
    indices = crossvalind('Kfold',labels',5);
cp = classperf(labels');
for ix = 1:5
    train = (indices == ix);
    if ix~=5
    train1= (indices==ix+1);
    else
    train1= (indices==1);
    end
    train2=train+train1;
    train2=train2>0;
    test = ~train2;
    k=1;
    tic

% k2=1;
% for i=-5:0.5:3
% for j=0:0.5:10
% 
% svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale',(2^(i)),'BoxConstraint',2^j);
% CVSVMModel = crossval(svmmodel,'KFold',5);
% classLoss(k2) = kfoldLoss(CVSVMModel);
% S(:,k2)=[i;j];
% k2=k2+1;
% end
% end
% [idx Lo]=min(classLoss);
% svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale',(2^(S(1,Lo))),'BoxConstraint',2^S(2,Lo));
svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale','auto');

[labelpredict,score]=predict(svmmodel,out(test,:));
conf=confusionmat(labels(:,test),labelpredict);
acc(ix)=(conf(1,1)+conf(2,2))/size(out(test,:),1);
Time(ix)=toc;
ClassNames=[1;2];
ClassNames=ClassNames<2;
% score(:,ClassNames);


k=k+1;
    

    classperf(cp,labelpredict,test);
end
labelpredict=labelpredict<2;
labels2=labels(:,test)<2;
score(:,ClassNames);
[Xsvm,Ysvm,Tsvm,AUC3] = perfcurve(labels2,score(:,ClassNames),'true');
se=find(Xsvm<=0.01);
tp=Ysvm(se(end,end));
tn=0.99;
perAcc(klx)=((tp+tn)/2)*100;

AreaUC(klx)=AUC3;

CX(klx)=mean(acc);
CY(klx)=sum(Time);
klx=klx+1;
end
% plot(Xsvm,Ysvm,'LineWidth',3);
% cp.ErrorRate;
Mean_AUC=mean(AreaUC)
Mean_acc=mean(CX)
Mean_time=sum(CY)
overallAcc=mean(perAcc)