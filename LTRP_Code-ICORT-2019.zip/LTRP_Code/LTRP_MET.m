%% LTrP method of texture analysis Coded by Sandula...


%%   National Institute of Technology Rourkela  %%







function [H1 H2 H3 H4 H5 H6 H7 H8 H9 H10 H11 H12 M ]=LTRP_MET(A)
[w1 w2]=size(A);
I1=padarray(A,[2,2],'symmetric');
Wei=[ 8 4 2;16 0 1;32 64 128];
W=zeros(3,3);
W1=zeros(3,3);
W2=zeros(3,3);
W3=zeros(3,3);
for i=3:w1+2
    for j=3:w2+2
        s1=I1(i,j+1)-I1(i,j);
        s2=I1(i-1,j)-I1(i,j);
        L_s=sqrt(s1^2+s2^2);
        
            hp1=I1(i,j+2)-I1(i,j+1);
            yp1=I1(i-1,j+1)-I1(i,j+1);
            L_p1=sqrt(hp1^2+yp1^2);
           
            hp2=I1(i-1,j+2)-I1(i-1,j+1);
            yp2=I1(i-2,j+1)-I1(i-1,j+1);
            L_p2=sqrt(hp2^2+yp2^2);
            
            hp3=I1(i-1,j+1)-I1(i-1,j);
            yp3=I1(i-2,j)-I1(i-1,j);
            L_p3=sqrt(hp3^2+yp3^2);
           
            hp4=I1(i-1,j)-I1(i-1,j-1);
            yp4=I1(i-2,j-1)-I1(i-1,j-1);
            L_p4=sqrt(hp4^2+yp4^2);
           
            yp5=I1(i-1,j-1)-I1(i,j-1);
            hp5=I1(i,j)-I1(i,j-1);
            L_p5=sqrt(hp5^2+yp5^2);
            
            yp6=I1(i,j-1)-I1(i+1,j-1);
            hp6=I1(i+1,j)-I1(i+1,j-1);
            L_p6=sqrt(hp6^2+yp6^2);
           
            hp7=I1(i+1,j+1)-I1(i+1,j);
            yp7=I1(i,j)-I1(i+1,j);
            L_p7=sqrt(hp7^2+yp7^2);
           
            hp8=I1(i+1,j+2)-I1(i+1,j+1);
            yp8=I1(i,j+1)-I1(i+1,j+1);
            L_p8=sqrt(hp8^2+yp8^2);
            S_L=[L_s-L_p4 L_s-L_p3 L_s-L_p2; L_s-L_p5 0 L_s-L_p1; L_s-L_p6 L_s-L_p7 L_s-L_p8] ;
S_4=S_L<0;
M(i-2,j-2)=sum(sum(S_4(:,:).*Wei));
            if s1>=45 && s2>=45
             W(2,3)=decision_ltrp(hp1,yp1);
             W(1,3)=decision_ltrp(hp2,yp2);
              W(1,2)=decision_ltrp(hp3,yp3);
               W(1,1)=decision_ltrp(hp4,yp4);
               W(2,1)=decision_ltrp(hp5,yp5);
                W(3,1)=decision_ltrp(hp6,yp6);
                 W(3,2)=decision_ltrp(hp7,yp7);
            W(3,3)=decision_ltrp(hp8,yp8);
S_w=W;
S_1=S_w==2;
S_2=S_w==3;
S_3=S_w==4;

H1(i-2,j-2)=sum(sum(S_1(:,:).*Wei));
H2(i-2,j-2)=sum(sum(S_2(:,:).*Wei));
H3(i-2,j-2)=sum(sum(S_3(:,:).*Wei));

        else if s1<45 && s2>=45
            W1(2,3)=decision_ltrp1(hp1,yp1);
            W1(1,3)=decision_ltrp1(hp2,yp2);
            W1(1,2)=decision_ltrp1(hp3,yp3);
            W1(1,1)=decision_ltrp1(hp4,yp4);
             W1(2,1)=decision_ltrp1(hp5,yp5);
            W1(3,1)=decision_ltrp1(hp6,yp6);
            W1(3,2)=decision_ltrp1(hp7,yp7);
            W1(3,3)=decision_ltrp1(hp8,yp8);
            S_w1=W1;
S_4=S_w1==1;
S_5=S_w1==3;
S_6=S_w1==4;
H1(i-2,j-2)=sum(sum(S_4(:,:).*Wei));
H2(i-2,j-2)=sum(sum(S_5(:,:).*Wei));
H3(i-2,j-2)=sum(sum(S_6(:,:).*Wei));
            else if s1<45 && s2<45
            W2(2,3)=decision_ltrp2(hp1,yp1);
            W2(1,3)=decision_ltrp2(hp2,yp2);
            W2(1,2)=decision_ltrp2(hp3,yp3);
            W2(1,1)=decision_ltrp2(hp4,yp4);
            W2(2,1)=decision_ltrp2(hp5,yp5);
            W2(3,1)=decision_ltrp2(hp6,yp6);
            W2(3,2)=decision_ltrp2(hp7,yp7);
            W2(3,3)=decision_ltrp2(hp8,yp8);
            S_w2=W2;
S_7=S_w2==1;
S_8=S_w2==2;
S_9=S_w2==4;
H1(i-2,j-2)=sum(sum(S_7(:,:).*Wei));
H2(i-2,j-2)=sum(sum(S_8(:,:).*Wei));
H3(i-2,j-2)=sum(sum(S_9(:,:).*Wei));
                else
            W3(2,3)=decision_ltrp3(hp1,yp1);
            W3(1,3)=decision_ltrp3(hp2,yp2);
            W3(1,2)=decision_ltrp3(hp3,yp3);
            W3(1,1)=decision_ltrp3(hp4,yp4);
            W3(2,1)=decision_ltrp3(hp5,yp5);
            W3(3,1)=decision_ltrp3(hp6,yp6);
            W3(3,2)=decision_ltrp3(hp7,yp7);
            W3(3,3)=decision_ltrp3(hp8,yp8);
            S_w3=W3;
S_10=S_w3==1;
S_11=S_w3==2;
S_12=S_w3==4;
H1(i-2,j-2)=sum(sum(S_10(:,:).*Wei));
H2(i-2,j-2)=sum(sum(S_11(:,:).*Wei));
H3(i-2,j-2)=sum(sum(S_12(:,:).*Wei));
                end
            end
            end
    end
end
[H4 H5 H6]=LTRP_Cal(I1,w1,w2);
[H7 H8 H9]=LTRP_Cal2(I1,w1,w2);
[H10 H11 H12]=LTRP_Cal3(I1,w1,w2);
