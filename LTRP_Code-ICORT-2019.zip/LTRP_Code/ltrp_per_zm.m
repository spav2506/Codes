
%% =========================== camera_classification.m ========================== %
%
% Description          :  Basically C-Svm coded classifier details....
%                         .
%                        
%                         
%                         
%
% Input parameters     :    ESME Feature vectors for Camera Zoom motion....
%
%
% Output parameters    :    Classification labels representing the
%                           predefined camera motion classes
%
% Subroutine  called   :    NA
% Called by            :    NA
% Reference            :    1)C.-C. Chang and C.-J. Lin, "LIBSVM: A library for support vector machines,"ACM 
%                             Transactions on Intelligent Systems and Technology, vol. 2, pp. 27:1-27:27, 2011,
%                             software available at http://www.csie.ntu.edu.tw/ cjlin/libsvm
% Author of the code   :    Sandula Pavan (516ec6004@nitrkl.ac.in)
% Date of creation     :    24.01.2018
% --------------------------------------------------------------------- %
% Modified on          :    
% Modification details :    variable name and comments
% Modified By          :    
% ================================================================ %
%           ECE Department, NIT Rourkela, India.
% ================================================================ %



%%
clc;
clear all;
close all;
folds=5;k=1;
fp1=strcat('......\H.264\zoom\FV',num2str(1),'.csv');
    out=csvread(fp1);
for i1=2:1000
     fp1=strcat('.........\H.264\zoom\FV',num2str(i1),'.csv');
    new=csvread(fp1);  % Read the nth file
   out = vertcat(out, new);   % Concatenate "out" with the 2nd column from new file
end
for j1=1:1000
    fp25=strcat('.......\H.264\non-zoom\FV',num2str(j1),'.csv');
    new2=csvread(fp25);
    out=vertcat(out,new2);
end

labels(1:1000)=1;
    labels(1001:2000)=2;k=1;
    klx=1;Ax=0;Bx=0;
while(klx<=30)
    indices = crossvalind('Kfold',labels',5);
cp = classperf(labels');
for ix = 1:5
    train = (indices == ix);
    if ix~=5
    train1= (indices==ix+1);
    else
    train1= (indices==1);
    end
    train2=train+train1;
    train2=train2>0;
    test = ~train2;
    k=1;
    tic


svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale','auto');

[labelpredict,score]=predict(svmmodel,out(test,:));
conf=confusionmat(labels(:,test),labelpredict);
acc(ix)=(conf(1,1)+conf(2,2))/size(out(test,:),1);
Time(ix)=toc;
ClassNames=[1;2];
ClassNames=ClassNames<2;
% score(:,ClassNames);


k=k+1;
    

    classperf(cp,labelpredict,test);
end
labelpredict=labelpredict<2;
labels2=labels(:,test)<2;
score(:,ClassNames);
[Xsvm,Ysvm,Tsvm,AUC3] = perfcurve(labels2,score(:,ClassNames),'true');
se=find(Xsvm<=0.01);
tp=Ysvm(se(end,end));
tn=0.99;
perAcc(klx)=((tp+tn)/2)*100;

AreaUC(klx)=AUC3;

CX(klx)=mean(acc);
CY(klx)=sum(Time);
klx=klx+1;
end
% plot(Xsvm,Ysvm,'LineWidth',3);
% cp.ErrorRate;
Mean_AUC=mean(AreaUC)
Mean_acc=mean(CX)
Mean_time=sum(CY)
overallAcc=mean(perAcc)
%% [X,Y,AUC1,CX1,CY1,per_1acc1]=LTRP_ESME_PER();
%% [X1,Y1,AUC3,CX2,CY2,per_1acc2]=LTRP_GAN10_PER();
%% [X2,Y2,AUC4,CX3,CY3,per_1acc3]=LTRP_GAN20_PER();
%% [X3,Y3,AUC5,CX4,CY4,per_1acc4]=LTRP_GAN30_PER();
% % [X4,Y4,AUC6,CX5,CY5,per_1acc5]=GAN4_LTP_Roc();
 
% figure (1)
% plot(X,Y,'LineWidth',2)
% hold on
% plot(Xsvm,Ysvm,'LineWidth',2)
% hold on
% plot(X1,Y1,'LineWidth',2)
% hold on
% plot(X2,Y2,'LineWidth',2)
% hold on
                                                                                                                                                                                                                                         
% plot(X3,Y3,'LineWidth',2)

% xlabel('False Positive Rate')
% ylabel('True Positive Rate')


% legend('ESME','H.264','ESME_{gau-10}','ESME_{gau-20}','ESME_{gau-30}');