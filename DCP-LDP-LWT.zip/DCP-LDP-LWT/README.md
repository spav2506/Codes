# LDP_DWT

DiscretWavelet3.m 
LDP_MET.m
Angley_x.m
method_LDP.m .......  are the files
remaining from prof. Ivans Bajic(SFU) ,research group.

Line no. 79 onwards discrete wavelet

Line no. 20 onwards LDP the functions for Line 20 and Line 79 are there

