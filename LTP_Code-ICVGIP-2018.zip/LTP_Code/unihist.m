function [pattern]=unihist(m)
%function to extract uniform pattern 
    pattern=zeros(1,58);
    [a,b]=size(m);
    m=m(:);
    n=a*b;
    unipat=[0;1;2;3;4;6;7;8;12;14;15;16;24;28;30;31;32;48;56;60;62;63;64;96;112;120;124;126;127;128;129;131;135;143;159;191;192;193;195;199;207;223;224;225;227;231;239;240;241;243;247;248;249;251;252;253;254;255];
    %"unipat have all 58 uniform patterns"
    for i=1:58
        k=(m==unipat(i));
        pattern(i)=sum(k);
    end
    k=sum(pattern);
    p=isnan(m);  %count number of NAN in matrix
    p=sum(p);
    nup=n-k-p; % gives number of non uniform patterns
    pattern=[pattern nup];
end