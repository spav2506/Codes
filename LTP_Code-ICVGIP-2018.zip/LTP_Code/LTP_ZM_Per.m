%% =========================== camera_classification.m ========================== %
%
% Description          :  Basically C-Svm coded classifier details....
%                         .
%                        
%                         
%                         
%
% Input parameters     :    ESME Feature vectors for Camera Zoom motion....
%
%
% Output parameters    :    Classification labels representing the
%                           predefined camera motion classes
%
% Subroutine  called   :    NA
% Called by            :    NA
% Reference            :    1)C.-C. Chang and C.-J. Lin, "LIBSVM: A library for support vector machines,"ACM 
%                             Transactions on Intelligent Systems and Technology, vol. 2, pp. 27:1-27:27, 2011,
%                             software available at http://www.csie.ntu.edu.tw/ cjlin/libsvm
% Author of the code   :    Sandula Pavan (516ec6004@nitrkl.ac.in)
% Date of creation     :    24.01.2018
% --------------------------------------------------------------------- %
% Modified on          :    
% Modification details :    variable name and comments
% Modified By          :    
% ================================================================ %
%           ECE Department, NIT Rourkela, India.
% ================================================================ %








%%
clc;
clear all;
close all;
%%% Fold details of classifier....

folds=5;k=1;
%%% Merging the details of feature vectors into a matrix.
fp1=strcat('.\H.264\zoom\FV',num2str(1),'.csv');
    out=csvread(fp1);
for i1=2:1000
    fp1=strcat('.\H.264\zoom\FV',num2str(i1),'.csv');
    new=csvread(fp1);  % Read the nth file
    out = vertcat(out, new);   % Concatenate "out" with the 2nd column from new file
end
for j1=1:1000
   fp25=strcat('.\H.264\non-zoom\FV',num2str(j1),'.csv');
   new2=csvread(fp25);
   out=vertcat(out,new2);
end
%%%%% Keeping labels manually........
    labels(1:1000)=1;
    labels(1001:2000)=2;k=1;
    klx=1;Ax=0;Bx=0;
%%%%% Iterating over 30 times.....
% while(klx<=30)
%%%%%%%%% Cross Fold validation of 2-5.......
    indices = crossvalind('Kfold',labels',5);  
for ix = 1:5
cp = classperf(labels');
    train = (indices == ix);
    if ix~=5
    train1= (indices==ix+1);
    else
    train1= (indices==1);
    end
    train2=train+train1;
    train2=train2>0;
    test = ~train2;
    k=1;
    tic
%%%%%% Training through C-svm model......
k2=1;
for i=-5:0.5:3
for j=0:0.5:10

svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale',(2^(i)),'BoxConstraint',2^j);
CVSVMModel = crossval(svmmodel,'KFold',5);
classLoss(k2) = kfoldLoss(CVSVMModel);
S(:,k2)=[i;j];
k2=k2+1;
end
end
[idx Lo]=min(classLoss);
svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale',(2^(S(1,Lo))),'BoxConstraint',2^S(2,Lo));
% svmmodel=fitcsvm(out(train2,:),labels(:,train2),'KernelFunction','rbf','Kernelscale','auto');

[labelpredict,score]=predict(svmmodel,out(test,:));
conf=confusionmat(labels(:,test),labelpredict);
acc(ix)=(conf(1,1)+conf(2,2))/size(out(test,:),1);
Time(ix)=toc;
ClassNames=[1;2];
ClassNames=ClassNames<2;
% score(:,ClassNames);


k=k+1;
    


    classperf(cp,labelpredict,test);
end
labelpredict=labelpredict<2;
labels2=labels(:,test)<2;
score(:,ClassNames);
[Xsvm1,Ysvm1,Tsvm1,AUC3x] = perfcurve(labels2,score(:,ClassNames),'true');
se=find(Xsvm1<=0.01);
tp=Ysvm1(se(end,end));
tn=0.99;
perAcc(klx)=((tp+tn)/2)*100;

AreaUC(klx)=AUC3x;

CX(klx)=mean(acc);
CY(klx)=sum(Time);
klx=klx+1;
% end

% cp.ErrorRate;
Mean_AUC=mean(AreaUC)
Mean_acc=mean(CX)
Mean_time=sum(CY)
overallAcc=mean(perAcc)
%%%%%%% Experiment analysis.........
[X11,Y11,AUC11,CX11,CY11,per_1acc11]=ESME_LTPZM_Roc();
 [X12,Y12,AUC32,CX22,CY22,per_1acc22]=GAN10_LTPZM_Roc();
 [X23,Y23,AUC43,CX33,CY33,per_1acc33]=GAN20_LTPZM_Roc();
 [X34,Y34,AUC54,CX44,CY44,per_1acc44]=GAN30_LTPZM_Roc();
%%%%%%%% Plotting ROC Curve details............
figure (4)
 plot(X11,Y11,'LineWidth',2)
hold on
plot(Xsvm1,Ysvm1,'LineWidth',2)
hold on
plot(X12,Y12,'LineWidth',2)
hold on
plot(X23,Y23,'LineWidth',2)
hold on
                                                                                                                                                                                                                                         
plot(X34,Y34,'LineWidth',2)
%%%%%%%%% Plotted Roc details......................................
xlabel('False Positive Rate')
ylabel('True Positive Rate')
% legend('H.264')
 legend('ESME','H.264','ESME_{gau-10}','ESME_{gau-20}','ESME_{gau-30}')
%  