function [ sumkl] = Ratio_h( H1,H2)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
XH1=H1;
XH2=H2;
ri=size(H1,2);
% DIS=((H1))./(H2);
    for i=1:ri
        if(XH1(i)~=0&&XH2(i)~=0)
        DIS(i)=XH2(i)/XH1(i);
        end
        if(XH1(i)==0&& XH2(i)~=0)
            DIS(i)=0;
        end
        if(XH1(i)==0&&XH2(i)==0)
            DIS(i)=0;
        end
        if(XH1(i)~=0&&XH2(i)==0)
            DIS(i)=0;
        end        
%     end
sumkl=(DIS);
end