%% =========================== zoomcameramotion_detection&classification.m ========================== %
%
% Description          :  This code is used for "Getting features for zoom camera motion detection
%                         and classification" using LTP texture analysis
%                         method.We basically aim at representing the 
%                         compressed domain block motion vectors in 
%                         orientation space and finding the upper and lower patterns of LBP
%                         and dimensionality reduction using uniform patterns are considered separately 
%                         by concatenating both and its ratio for feeding the feature vectors.... 
%                         
%                        
%                         
%                         
%
% Input parameters     :    ESME block motion vectors
%
%
% Output parameters    :    Classification labels representing the
%                           predefined camera motion classes
%
% Subroutine  called   :    NA
% Called by            :    NA
% Reference            :    1)Xiaoyang Tan and Bill Triggs,"Enhanced Local Texture Feature Sets for Face
%                             Recognition Under Difficult Lighting Conditions" IEEE 
%                             transaction on image processing, VOL. 19,No. 6, June 2010 
% Author of the code   :    Sandula Pavan (pavannit4@gmail.com)
% Date of creation     :    24.01.2018
% --------------------------------------------------------------------- %
% Modified on          :    
% Modification details :    variable name and comments
% Modified By          :    
% ================================================================ %
%           ECE Department, NIT Rourkela, India.
% ================================================================ %





%%
clc;
clear all;
close all;

%% Path to dataset 

%% Intialization of Block height and width and Weighs
weight5=[2^0 2^1 2^2;2^7,0,2^3;2^6,2^5,2^4];
BLK_H=72%60 72

BLK_W=88%
path='G:\H.264\non-zoom\matlabmv_';
path='G:\H.264\zoom_in\matlabmv_';
path='G:\H.264\zoom_out1\matlabmv_';

HALF_PIX=0.5;
% mn=0;nm=0;
t23=1;
%% Main code starts with different motion vector frame count
for frameNum=1:1
    
    t23;
    t35=0;
%% ESME Zoom-in and zoom-out data
%      if t23>122 && t23<=166 %%zoom-out
% BLK_H=60;
%     else
%         BLK_H=72;
%  end
%     if t23>=122 && t23<164 %% zoom-in
% BLK_H=60;
%     else
%         BLK_H=72;
%     end
% %%    
    %% H.264 Zoom-in and zoom-out data
  if t23>124 && t23<168 %% zoom-in (+) %% zoom-out(+=)
BLK_H=60;
    else
        BLK_H=72;
    end
%%

% % % % % % % % % % % % % writeMVs(path,frameNum,path2,t23);
%%
%% Read motion vector.
[mv_x, mv_y] = ReadMVs(path, frameNum, BLK_H, BLK_W, HALF_PIX);
% if frameNum==2
% [mv_x, mv_y] = ReadMVs(path2, frameNum, BLK_H, BLK_W, HALF_PIX);
% end
L=sqrt(mv_x.^2+mv_y.^2);
[w1 w2]=size(mv_x);

%%
%% quiver plot for mvs
figure(1)
h= quiver(mv_y,mv_x);
%% Fix center and find corresponding angles with it for quiver plot
    a=(h.UData);
    b=(h.VData);
    Mon=0;


 for p=1:size(a,1)
    for q=1:size(a,2)
        if a(p,q)>0 && b(p,q)>0 
            A(p,q)= 180*atan(b(p,q)/a(p,q))/pi;
            Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
        end
        if a(p,q)<0 && b(p,q)>0
            A(p,q)=90+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
             Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
        end
        
        if a(p,q)<0 && b(p,q)<0
            A(p,q)=180+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
             Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
        end
        
        if a(p,q)>0 && b(p,q)<0
            A(p,q)=270+180*atan(abs(b(p,q))/abs(a(p,q)))/pi;
              Angle(p,q)=180*atan(b(p,q)/a(p,q))/pi;
        end
        if a(p,q)<0 && b(p,q)==0
            A(p,q)=180;
            Angle(p,q)=-180;
        end
        if a(p,q)==0&& b(p,q)<0
            A(p,q)=270;
            Angle(p,q)=-90;
        end
        if a(p,q)==0 && b(p,q)>0
            A(p,q)=90;
            Angle(p,q)=90;
        end
        if a(p,q)>0 && b(p,q)==0
            A(p,q)=0;
            Angle(p,q)=0;
        end
        if a(p,q)==0 && b(p,q)==0
            A(p,q)=0;
            Angle(p,q)=0;
        end
    end
end
%% Padding Angle 2D by [1 1] with same as edges as in Angle 2D
D3=padarray(A,[1,1],'symmetric');
Dr=padarray(Angle,[1,1],'symmetric');

rw=0;rw2=0;re2=0;re3=0;re4=0;fr=0;ft=0;fs=0;
%% Assigning ternary patterns to different orientation levels
for l=2:w1+1
    for m=2:w2+1

        rw1=0;rx=0;ry=0;rs=0;hy=0;
     for u=1:3
       for v=1:3
          x=D3(l+u-2,m+v-2);
          Tq1=(x);
          
          t=((D3(l,m)));

%% upper local ternary pattern for orientation space divided between 0-360
              if ((Tq1))>=t+45 
                  w(u,v)=1;
%               else
%                   w(u,v)=0;
              end
%%               
              if (abs(Tq1-t))<45
                  w(u,v)=0;
              end
%% similarly lower ternary pattern
              if (Tq1)<=t-45
                  w(u,v)=-1;
              end
           y= Dr(l+u-2,m+v-2);
           
           s=Dr(l,m);
%% 
       end
     end
     w9=w;


     w91=w9<0;
     w10=w9>0;

     d09(l-1,m-1)=sum(sum(w91(:,:).*weight5(:,:)));
     d10(l-1,m-1)=sum(sum(w10(:,:).*weight5(:,:)));

    end
end
%% 58 uniform patterns of histogram was consider map of Local ternary patterns
d11=((d10-d09));
Der=hist(d11(:),256);
H1=unihist(d09);
H2=unihist(d10);
h1=H1./(w1*w2);
h2=H2./(w1*w2);
% Zoom motion classification
Aer=Ratio_h(h2,h1);
Der=[h1 h2];

    %% Concatenating the histogram for zoom detection
% Aer=[h1(:);h2(:)];
fv=[Aer];
% filename3 =strcat('G:\ConcHist\train8\H.264\zoom-in6\FV',num2str(t23),'.csv');
% csvwrite(filename3,fv);
  t23=t23+1;
end
